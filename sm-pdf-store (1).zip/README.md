# SM PDFs Store

A responsive storefront for your PDFCart account.

## How it works
- The website displays the current five products from `https://pdfcart.in/@smpdfs`.
- Every **Buy now** button opens the corresponding official PDFCart product page in a new tab.
- Payment, UPI/cards/netbanking checkout, and post-payment PDF delivery remain handled by PDFCart.
- No PDFCart password, API key, payment secret, or buyer data is stored in this website.

## Run
Open `index.html` in a browser, or upload the folder to any static hosting service.

## Updating products
Edit the `products` array in `script.js` with the product name, price, description, mode, emoji, and official PDFCart product URL.

## Important
This is an integration by linking to your PDFCart storefront/product checkout. PDFCart's public pages do not expose a documented seller API in the information available here, so this site does not pretend to have private account/API access.
