const products = [
  {name:"Shreyash Iyer Fan Cards", price:120, mode:"download", emoji:"🏏", desc:"Fan cards made for Shreyash Iyer fans.", url:"https://pdfcart.in/p/chatgpt-image-oct-1-2026-04-09-53-pm", tag:"Fan favourite"},
  {name:"GET WELL SOON Cards", price:150, mode:"download", emoji:"💐", desc:"Thoughtful get-well-soon cards in a ready-to-use PDF.", url:"https://pdfcart.in/p/get-well-soon-cards", tag:"Cards"},
  {name:"Stolen Vows Novel Edition", price:75, mode:"read", emoji:"📖", desc:"Read the novel online anytime after purchase.", url:"https://pdfcart.in/p/stolen-vows-novel-edition", tag:"Read online"},
  {name:"Love cards", price:150, mode:"download", emoji:"💌", desc:"A collection of 8 different love cards.", url:"https://pdfcart.in/p/love-cards", tag:"Cards"},
  {name:"Birthday cards", price:200, mode:"download", emoji:"🎂", desc:"17 different birthday cards for adults.", url:"https://pdfcart.in/p/business-card-25-sep-2026", tag:"Cards"}
];
const palettes=["linear-gradient(135deg,#ffd5dc,#fff0d7)","linear-gradient(135deg,#d9f5ea,#fff1c9)","linear-gradient(135deg,#ddd6ff,#f4e2ff)","linear-gradient(135deg,#ffd8ec,#e3dcff)","linear-gradient(135deg,#ffe2bd,#ffd3dc)"];
const grid=document.querySelector("#grid"), empty=document.querySelector("#empty"), search=document.querySelector("#search"), filter=document.querySelector("#filter");
function render(){
  const q=search.value.toLowerCase().trim(), f=filter.value;
  const list=products.filter(p=>(f==="all"||p.mode===f)&&(p.name+" "+p.desc+" "+p.tag).toLowerCase().includes(q));
  grid.innerHTML=list.map((p,i)=>`<article class="product">
    <div class="cover" style="background:${palettes[products.indexOf(p)%palettes.length]}">
      <span class="type">${p.mode==="read"?"READ ONLINE":"DOWNLOAD"}</span><span class="emoji">${p.emoji}</span>
    </div>
    <div class="p-body"><h3>${p.name}</h3><p>${p.desc}</p>
      <div class="meta"><span class="price">₹${p.price}</span><a class="buy" href="${p.url}" target="_blank" rel="noopener">Buy now ↗</a></div>
    </div>
  </article>`).join("");
  empty.hidden=list.length!==0;
}
search.addEventListener("input",render); filter.addEventListener("change",render); document.querySelector("#year").textContent=new Date().getFullYear(); render();
